import MovieCardGrid from "../components/MovieCardGrid";

function Home() {
  return (
    <div className={"w-full"}>
      <MovieCardGrid />
    </div>
  );
}
export default Home;
